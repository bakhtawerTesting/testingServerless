package constants

var (
	Username    string
	Password    string
	FromAddress string
)
